<?php

    $server = "localhost";
    $user = "root";
    $passdb = "";
    $db = "onlclassroom";
    $connect = mysqli_connect( $server, $user, $passdb, $db )or die( "Connection Error" );

?>